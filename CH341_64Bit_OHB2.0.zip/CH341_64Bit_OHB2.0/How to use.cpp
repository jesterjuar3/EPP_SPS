//Uninstall the original drivers and install the latest 64Bit one in CH341_64Bit_Driver folder
//put CH341DLLA64.DLL C:\ets\bin
//CH341DLLA64.H C:\ets\inc
//CH341DLLA64.LIB C:\ets\lib
//Add CH341DLLA64.LIB to Linker->Input (Project Property)
//#include "expansion_bits.h"

UserInit( void )
{
	//i2cmode( I2C_130KHZ );
	//lwait (5 mSec);
	
	xbit.init(); //Initialize the I2C ICs output to low->Xbit module output to high.
	lwait (5 mSec);
	cbitclose (K31_FLOATING_RELAYPOWER_5V12V); //must be after xbit.init()
	lwait (200 mSec);
	
	
	
	
	
	
	// Board ID check
    const UCHAR Apps_Bd_Address    = 0xA0;  //0000
    const UCHAR HeadboxA_Address   = 0xAC; //1100
    const UCHAR HeadboxB_Address   = 0xAE; //1110     //0xA4;  //0100
    const UCHAR Socket_Bd_Address  = 0xA8;  //1000

    const UINT ID_len   = 8;
    const UINT WRITE_ID = 0; //Write this parameter 1 to allow the ID writing operations. 
  
    UCHAR Apps_Bd_ID   [10] = {"DC_APPNA"};
    UCHAR HeadboxA_ID   [10] = {"DC_A_VNA"};
    UCHAR HeadboxB_ID   [10] = {"DC_B_VNA"};
    UCHAR Socket_Bd_ID [10] = {"DC_S_VNA"};
    UCHAR Read_data    [10] = {"XXXXXXXX"};
  
    int i2c_status = -1;
    int checksum = 0;
	
	//HeadboxB ID check
	  
     if(WRITE_ID)
      {
        //i2cramwrite( HeadboxB_Address,  0, HeadboxB_ID, ID_len );
		 xbit.usb_i2cramwrite(HeadboxB_Address, 0, HeadboxB_ID, ID_len);
        lwait(10 ms);
      }
  
     //i2c_status = i2cramread( HeadboxB_Address, 0, Read_data, ID_len );
	  i2c_status = xbit.usb_i2cramread(HeadboxB_Address, 0, Read_data, ID_len);
     lwait(1 ms);
  
     for( int i=0; i<ID_len; i++ )   
      {
        checksum += (Read_data[i] == HeadboxB_ID[i]);
      }
  
     if ( checksum != ID_len || i2c_status == FAILURE ) //xbit.usb_i2cramread() return read byte count
      {
        etsMessageBox("\nDC_HeadBoxB failed the ID checking!!!\n"
        "\nPlease consult engineer to check hardware!!!", MB_OK | MB_ICONSTOP);
        return FALSE;
      }
	  else
	  {
		 etsprintf ("\nAPM32 DC HeadBoxB Detected."); 	  
	  }
     checksum = 0;
     i2c_status = -1;
	
}

UserExit( void )
{
	xbit.exit();
	//if (online)
	//{
		//TRU_Exit( );
		//BarcodeReader_Close();
		cbitopen (K31_FLOATING_RELAYPOWER_5V12V);	//Disable Relay Power.  - Mar13
	//}
	return TRUE;
}

OnTestStartup( void )
{
	xbit.clear();
}

OnTestCompletion( void )
{
	xbit.clear ();
}

OnFailSite( int site )
{
	xbit.clear();
}
